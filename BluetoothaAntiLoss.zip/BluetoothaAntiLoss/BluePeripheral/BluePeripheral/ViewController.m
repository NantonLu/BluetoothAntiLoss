//
//  ViewController.m
//  BluePeripheral
//
//  Created by Nanton on 16/1/16.
//  Copyright © 2016年 Nanton. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<CBPeripheralManagerDelegate>
@property(nonatomic,strong)CBMutableCharacteristic *customCharacteristic;
@property(nonatomic,strong)CBMutableService *customService;
@property(nonatomic,strong)CBPeripheralManager *peripheralManager;
@property(nonatomic,strong)NSTimer *timer;
@end

@implementation ViewController
static NSString * const kServiceUUID = @"5C4EDBDE-5BA8-45EB-A767-9FA089288193";//服务用uuid
static NSString * const kCharacteristicUUID = @"7E8F0AEC-1564-4774-9772-ABD813E8D642";//特征用uuid

- (void)viewDidLoad {
    [super viewDidLoad];
    self.peripheralManager = [[CBPeripheralManager alloc]initWithDelegate:self queue:nil];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
    
    switch (peripheral.state)
    {
            
        case CBPeripheralManagerStatePoweredOn:
            NSLog(@"CBPeripheralManagerStatePoweredOn");
            [self setupService];
            break;
        default:
            NSLog(@"Peripheral Manager did change state");
            break;
            
    }
    
}
//设置周边设备的服务和特征
- (void)setupService {
    
    // Creates the characteristic UUID
    
    CBUUID *characteristicUUID = [CBUUID UUIDWithString:kCharacteristicUUID];
    
    // Creates the characteristic,创建了一个特征以后
    
    self.customCharacteristic = [[CBMutableCharacteristic alloc] initWithType:
                                 
                                 characteristicUUID properties:CBCharacteristicPropertyNotify
                                 
                                                                        value:nil permissions:CBAttributePermissionsWriteable];
    
    // Creates the service UUID
    
    CBUUID *serviceUUID = [CBUUID UUIDWithString:kServiceUUID];
    
    // Creates the service and adds the characteristic to it,创建了一个服务
    
    self.customService = [[CBMutableService alloc] initWithType:serviceUUID
                          
                                                        primary:YES];
    
    // Sets the characteristics for this service，将特征添加到了服务上
    
    [self.customService setCharacteristics:@[self.customCharacteristic]];
    
    // Publishes the service，把服务添加到周边管理者（Peripheral Manager）是用于发布服务
    
    [self.peripheralManager addService:self.customService];
    NSLog(@"设置周边设备的服务和特征");
    
}
//一旦发布服务后，调用该方法
- (void)peripheralManager:(CBPeripheralManager *)peripheral didAddService:(CBService *)service error:(NSError *)error {
    if (error == nil)
    {
        // Starts advertising the service,开始广播服务
        [self.peripheralManager startAdvertising:@{ CBAdvertisementDataLocalNameKey :
                                                        @"ICServer", CBAdvertisementDataServiceUUIDsKey :@[[CBUUID UUIDWithString:kServiceUUID]] }];
//        [self.peripheralManager startAdvertising:nil];
        NSLog(@"开始广播服务");
    }
    NSLog(@"进入‘一旦发布服务后，调用该方法’");
}

//开始广播后，接受消息
-(void)peripheralManagerDidStartAdvertising:(CBPeripheralManager *)peripheral error:(NSError *)error
{
    NSLog(@"已经开始广播");
}
//订阅特征
-(void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didSubscribeToCharacteristic:(CBCharacteristic *)characteristic
{
    NSLog(@"订阅了 %@的数据",characteristic.UUID);
    //每秒执行一次给主设备发送一个当前时间的秒数
//    self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(sendData:) userInfo:characteristic  repeats:YES];
}
//取消订阅characteristics
-(void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didUnsubscribeFromCharacteristic:(CBCharacteristic *)characteristic{
    NSLog(@"取消订阅 %@的数据",characteristic.UUID);
    [self.peripheralManager startAdvertising:@{ CBAdvertisementDataLocalNameKey :
                                                    @"ICServer", CBAdvertisementDataServiceUUIDsKey :@[[CBUUID UUIDWithString:kServiceUUID]] }];
    //取消回应
    [self.timer invalidate];
}
//发送数据，发送当前时间的秒数
-(BOOL)sendData:(NSTimer *)t {
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [formatter setDateFormat:@"YYYY-MM-dd hh:mm:ss"];
    NSString *DateTime = [formatter stringFromDate:[NSDate date]];
    NSLog(@"当前发送的数据是：%@",DateTime);
    //执行回应Central通知数据
    CBMutableCharacteristic *characteristic = t.userInfo;
    return  [self.peripheralManager updateValue:[[formatter stringFromDate:[NSDate date]] dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:(CBMutableCharacteristic *)characteristic onSubscribedCentrals:nil];
}
//响应中心设备的读写请求
- (void)respondToRequest:(CBATTRequest *)request withResult:(CBATTError)result;
{
    NSLog(@"响应中心设备的读写请求:%@",request);
    NSLog(@"响应中心设备的读写请求:%@",request.value);
}
//读characteristics请求
- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveReadRequest:(CBATTRequest *)request{
    NSLog(@"didReceiveReadRequest");
    //判断是否有读数据的权限
    if (request.characteristic.properties & CBCharacteristicPropertyRead &CBCharacteristicPropertyWriteWithoutResponse) {
        NSData *data = request.characteristic.value;
        NSLog(@"读取的特征值为：%@",data);
        [request setValue:data];
        //对请求作出成功响应
        [self.peripheralManager respondToRequest:request withResult:CBATTErrorSuccess];
    }else{
        [self.peripheralManager respondToRequest:request withResult:CBATTErrorWriteNotPermitted];
    }
}
//写characteristics请求
- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveWriteRequests:(NSArray *)requests{
    NSLog(@"didReceiveWriteRequests");
    CBATTRequest *request = requests[0];
    //判断是否有写数据的权限
    if (request.characteristic.properties & CBCharacteristicPropertyWrite)
    {
        //需要转换成CBMutableCharacteristic对象才能进行写值
        CBMutableCharacteristic *c =(CBMutableCharacteristic *)request.characteristic;
        c.value = request.value;
        [self.peripheralManager respondToRequest:request withResult:CBATTErrorSuccess];
    }else
    {
        [self.peripheralManager respondToRequest:request withResult:CBATTErrorWriteNotPermitted];
    }
}

//当中央预定了这个服务,这儿是你给中央生成动态数据的地方
//三、Peripheral 发送广播 advertising：peripheralManagerDidStartAdvertising:error
//
//Peripheral 添加 service：peripheralManager:didAddService:error
//四、对 central 的操作进行响应
//
//读 characteristics 请求：peripheralManager:didReceiveReadQuest:
//写characteristics 请求：peripheralManager:didReceiveWriteRequests:
//订阅特征：peripheralManager:central:didSubscribeToCharacteristic:
//取消订阅：peripheralManager:central:didUnsubscribeFromCharacteristic:
//一些基本属性：
//
//RSSI：信号强弱值，防丢器会用到。
//UUID：唯一标识符，用于区分设备
//service UUID：服务，一个 Server 会包含多个characteristic，用 UUID 来区分。
//characteristic：特征，用 UUID 来区分
@end



