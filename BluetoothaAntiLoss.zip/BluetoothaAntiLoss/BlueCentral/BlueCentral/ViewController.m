//
//  ViewController.m
//  BlueCentral
//
//  Created by Nanton on 16/1/16.
//  Copyright © 2016年 Nanton. All rights reserved.
//

#import "ViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>
@interface ViewController ()<CBCentralManagerDelegate,CBPeripheralDelegate>
@property (nonatomic, strong) CBCentralManager *manager;//中央设备管理者
@property (nonatomic, strong) NSMutableData *data;
@property (nonatomic, strong) CBCharacteristic *characteristic;
@property (strong, nonatomic) IBOutlet UITextView *result;
@property (nonatomic,strong)CBPeripheral *peripheral;//在中央这边，一个CBPeripheral 对象代表着相应的和中央连接着的周边
@property (strong, nonatomic) NSTimer *timer;
@property (nonatomic,strong) UILocalNotification *localNotifi;
@end

@implementation ViewController
static NSString * const kServiceUUID = @"5C4EDBDE-5BA8-45EB-A767-9FA089288193";
static NSString * const kCharacteristicUUID = @"7E8F0AEC-1564-4774-9772-ABD813E8D642";
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.manager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    self.localNotifi = [UILocalNotification new];
    [[UIApplication sharedApplication] scheduleLocalNotification:self.localNotifi];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)readRSSI
{

    if (self.peripheral) {
        [self.peripheral readRSSI];
    }
}
//检测蓝牙是否可用
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    
    switch (central.state)
    {
            
        case CBCentralManagerStatePoweredOn:
            NSLog(@"蓝牙可用，开始扫描");
            // 扫描指定的服务
            [self.manager scanForPeripheralsWithServices:@[[CBUUID UUIDWithString:kServiceUUID]]
                                                 options:@{CBCentralManagerScanOptionAllowDuplicatesKey : @YES }];
            //扫描所有服务
//            [self.manager scanForPeripheralsWithServices:nil options:nil];
            break;
        default:
            NSLog(@"Central Manager did change state");
            break;
            
    }
    
}
//一旦一个周边在寻找的时候被发现，中央的代理会收到以下回调，任何广播、扫描的响应数据保存在advertisementData
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral
     advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    NSLog(@"发现周边设备：Connecting to peripheral %@,RSSI:%@ ,advertisementData:%@", peripheral,RSSI,advertisementData);
    self.result.text = [NSString stringWithFormat:@"发现周边设备：Connecting to peripheral %@,RSSI:%@", peripheral,RSSI];
   
    self.peripheral = peripheral;
    [self.manager connectPeripheral:peripheral options:@{CBConnectPeripheralOptionNotifyOnConnectionKey: @YES, CBConnectPeripheralOptionNotifyOnDisconnectionKey: @YES, CBConnectPeripheralOptionNotifyOnNotificationKey: @YES}];
//    CBConnectionPeripheralOptionNotifyOnConnectionKey---当你想要你的系统在挂起状态时候，正好有一个连接成功执行，系统抛出一个连接警告
//    CBConnectionPeripheralOptionNotifyOnDisconnectKey---当你想要你的系统在你的APP挂起状态收到任何断开连接事件的时候抛出一个断开连接警告
//    CBConnectionPeripheralOptionNotifyOnNotifycationKey---当你想要你的系统在你的APP处于挂起状态时候，收到的任何notification都爆出一个警告的时候使用

}
//连接成功
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
     NSLog(@"连接成功");
    [self presentLocalNotificationNow: @"连接成功"];
    [self readRSSI];
//    self.peripheral.delegate = self;
//    if (!self.timer)
//    {
//        self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0
//                                                      target:self
//                                                    selector:@selector(readRSSI)
//                                                    userInfo:nil
//                                                     repeats:60.0];
//        [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSDefaultRunLoopMode];
//        if ([peripheral.name isEqualToString:@"ICServer"])
//        {
//
//        }
//        
//    }
    
    // Clears the data that we may already have
    
//    [self.data setLength:0];
    
    // Sets the peripheral delegate
    [self.peripheral setDelegate:self];
    // Asks the peripheral to discover the service，连接指定的服务
    [self.peripheral discoverServices:@[ [CBUUID UUIDWithString:kServiceUUID] ]];
    [self.manager stopScan];
    //连接所有
//    [self.peripheral discoverServices:nil];
    
}
//连接失败
-(void)centralManager:(CBCentralManager *)central  didFailToConnectPeripheral:(nonnull CBPeripheral *)peripheral error:(nullable NSError *)error
{
    NSLog(@"连接失败，错误为：%@",error);
}
//当已经与peripheral建立的连接断开时调用
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"连接断开");
    [self presentLocalNotificationNow: @"连接断开"];
    [self.manager scanForPeripheralsWithServices:@[[CBUUID UUIDWithString:kServiceUUID]]
                                         options:@{CBCentralManagerScanOptionAllowDuplicatesKey : @YES }];
     [self.manager connectPeripheral:peripheral options:@{CBConnectPeripheralOptionNotifyOnConnectionKey: @YES, CBConnectPeripheralOptionNotifyOnDisconnectionKey: @YES, CBConnectPeripheralOptionNotifyOnNotificationKey: @YES}];
//    [self.manager connectPeripheral:peripheral options:nil];
    
}
//当找到了服务之后，就能进入didDiscoverServices的回调
- (void)peripheral:(CBPeripheral *)aPeripheral didDiscoverServices:(NSError *)error {
    
    if (error)
    {
        NSLog(@"Error discovering service:%@", [error localizedDescription]);
        //              [self cleanup];
        return;
    }
    
    for (CBService *service in aPeripheral.services)//便利aPeripheral里面的服务
    {
    
        NSLog(@"Service found with UUID: %@",service.UUID);
        
        // Discovers the characteristics for a given service，
        
//        if ([service.UUID isEqual:[CBUUID UUIDWithString:kServiceUUID]])
//        {
//            //                      发现给定服务的特性后，调用peripheral:(CBPeripheral *)peripheral       didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
            [self.peripheral discoverCharacteristics:@[[CBUUID UUIDWithString:kCharacteristicUUID]] forService:service];
//        }
    }
    
}
//一个特征被发现后，调用该方法
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    
    if (error)
    {
        
        NSLog(@"Error discovering characteristic:%@", [error localizedDescription]);
        //              [self cleanup];
        return;
    }
    
    if ([service.UUID isEqual:[CBUUID UUIDWithString:kServiceUUID]])
    {
        
        for (CBCharacteristic *characteristic in service.characteristics)
        {
            
            if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:kCharacteristicUUID]])
            {
                //                    特征的值被更新
                [peripheral setNotifyValue:YES forCharacteristic:characteristic];
                NSLog(@"特征uuid一样");
            }
        }
    }
    
}
//特征的值被更新后，触发该方法
- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:
(CBCharacteristic *)characteristic error:(NSError *)error
{
    
    if (error)
    {
        
        NSLog(@"Error changing notification state:%@", error.localizedDescription);
        
    }
    
    // Exits if it's not the transfer characteristic
    
    if (![characteristic.UUID isEqual:[CBUUID UUIDWithString:kCharacteristicUUID]])
    {
        return;
    }
    // Notification has started，通知开始
    if (characteristic.isNotifying)
    {
        self.characteristic = characteristic;
        NSLog(@"Notification began on %@", characteristic);
//        读特征值
        [peripheral readValueForCharacteristic:characteristic];
        //界面上显示特征值
        self.result.text = [NSString stringWithFormat:@"%@",characteristic];
        
        
    }
    else
    { // Notification has stopped，通知结束
        
        // so disconnect from the peripheral，结束和周边设备的连接
        NSLog(@"Notification stopped on %@.Disconnecting", characteristic);
        [self.manager cancelPeripheralConnection:self.peripheral];
    }
}
//读特征值后的委托方法
-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    NSString *result = [[NSString alloc] initWithData:characteristic.value  encoding:NSUTF8StringEncoding];
    NSLog(@"读特征值后的委托方法,特征值为：%@",result);
    [self presentLocalNotificationNow:result];
   

}
//读取到RSSI值后的操作
- (void)peripheralDidUpdateRSSI:(CBPeripheral *)peripheral error:(NSError *)error
{
    if (!error)
    {
       NSLog(@"ICServer的rssi ： %ld", [[peripheral RSSI] integerValue]);
    }
}
- (IBAction)sendMessage:(id)sender
{

    //第一个参数是已连接的蓝牙设备 ；第二个参数是要写入到哪个特征； 第三个参数是通过此响应记录是否成功写入
    [self.peripheral writeValue:[@"123" dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:self.characteristic type:CBCharacteristicWriteWithoutResponse];

}
//写入数据后的回调方法
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(nonnull CBCharacteristic *)characteristic error:(nullable NSError *)error
{
    NSLog(@"写入数据错误原因：%@",error);
}
//外设服务变化时回调的方法
- (void)peripheral:(CBPeripheral *)peripheral didModifyServices:(nonnull NSArray<CBService *> *)invalidatedServices
{
    NSLog(@"设备服务变化");
    
    [self.manager scanForPeripheralsWithServices:@[[CBUUID UUIDWithString:kServiceUUID]]
                                         options:@{CBCentralManagerScanOptionAllowDuplicatesKey : @YES }];

}

- (void)peripheral:(CBPeripheral *)peripheral didReadRSSI:(NSNumber *)RSSI error:(NSError *)error
{
    //NSLog(@"%s,%@",__PRETTY_FUNCTION__,peripheral);
    int rssi = abs([peripheral.RSSI intValue]);
    CGFloat ci = (rssi - 49) / (10 * 4.);
    NSString *length = [NSString stringWithFormat:@"发现BLT4.0热点:%@,距离:%.1fm",_peripheral,pow(10,ci)];
    NSLog(@"距离：%@",length);
    [self presentLocalNotificationNow:[NSString stringWithFormat:@"距离：%@",length]];
}
//弹出本地通知
-(void)presentLocalNotificationNow:(NSString*)str
{
    self.localNotifi.alertBody = str;
    self.localNotifi.soundName = UILocalNotificationDefaultSoundName;
    self.localNotifi.applicationIconBadgeNumber = self.localNotifi.applicationIconBadgeNumber+1;
     [[UIApplication sharedApplication]presentLocalNotificationNow:self.localNotifi];
}
@end
